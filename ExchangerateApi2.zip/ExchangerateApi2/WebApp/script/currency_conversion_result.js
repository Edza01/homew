function showConversionResult(data) {
    var _a = ['result', 'rate', 'amount', 'amount', 'fromValue', 'toValue'].map(function (id) { return document.getElementById(id); }), result = _a[0], exchangeRate = _a[1], amount = _a[2], amount = _a[3], fromValue = _a[4], toValue = _a[5];
    if (data.result === 'success') {
        amount.textContent = "".concat(amount.value, " ").concat(fromValue.value, " =");
        result.textContent = "".concat(data.conversion_result, " ").concat(toValue.value);
        exchangeRate.textContent = "1 ".concat(fromValue.value, " = ").concat(data.conversion_rate, " ").concat(toValue.value);
    }
    else
        result.textContent = 'Conversion failed. Please try again.';
}
