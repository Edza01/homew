function initiateConversion () {
    var amount = parseFloat(document.getElementById('amount').value);
    
    if (isNaN(amount) || amount === 0) {
        document.getElementById('result').innerText = 'No valid amount entered';
        return;
    }

    var fromCurrency = document.getElementById('fromValue').value;
    var toCurrency = document.getElementById('toValue').value;

    fetch("https://localhost:7000/api/Exchangerates/exchange?cFrom=".concat(fromCurrency, "&cTo=").concat(toCurrency, "&amount=").concat(amount))
        .then(function (response) { return response.json(); })
        .then(function (data) { return showConversionResult(data); })
        .catch(function (error) { return console.error('Error fetching data:', error); });
}
