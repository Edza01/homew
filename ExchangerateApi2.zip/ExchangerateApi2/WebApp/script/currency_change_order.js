function changeCurrencyOrder() {
    var _a;
    _a = [toValue.value, fromValue.value], fromValue.value = _a[0], toValue.value = _a[1];
    initiateConversion ();
}
