var currencyOptions = ["EUR", "USD", "GBP", "ARS", "LYD"];

var getCurrencies = function () {
    ['fromValue', 'toValue'].forEach(function (id) {
        var selectElement = document.getElementById(id);
        selectElement.innerHTML = '';

        currencyOptions.forEach(function (currency) {
            var option = new Option(currency, currency);
            if ((id === 'fromValue' && currency === 'EUR') || (id === 'toValue' && currency === 'USD'))
                option.setAttribute('selected', 'selected');

            selectElement.add(option);
        });
    });
};

window.onload = getCurrencies;
