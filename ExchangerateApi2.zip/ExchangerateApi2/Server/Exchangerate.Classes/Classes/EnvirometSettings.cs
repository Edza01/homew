﻿using Microsoft.Extensions.Configuration;

namespace ExchangerateApi.Classes
{
    public class EnvirometSettings : IApiKeyEnvirometSettings
    {
        public string ApiKey { get; }

        public EnvirometSettings(IConfiguration configuration) =>
           ApiKey = configuration.GetValue<string>("ApiSettings:ExchangeRatesApiKey") ??
            throw new ApplicationException("API key error, check conf");
    }
}



