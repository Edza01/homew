﻿namespace ExchangerateApi
{
    public interface IApiKeyEnvirometSettings
    {
        string ApiKey { get; }
    }
}
