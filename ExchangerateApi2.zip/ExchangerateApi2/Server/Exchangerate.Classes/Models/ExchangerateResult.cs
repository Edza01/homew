﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace Exchangerate.Classes.Models
{
    public class ExchangerateResult
    {
        public string Result { get; set; } = string.Empty;
        public string Documentation { get; set; } = string.Empty;
        
        [JsonPropertyName("conversion_rates")]
        public Dictionary<string, double>? ConversionRates { get; set; }
    }
}
