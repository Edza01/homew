﻿using System.Text.Json.Serialization;

namespace Exchangerate.Classes.Models
{
    public class ExchangeResultFromCurrenciesAndAmount
    {
        public string Result { get; set; } = string.Empty;
        public string Documentation { get; set; } = string.Empty;
        
        [JsonPropertyName("conversion_rate")]
        public double ConversionRate { get; set; }
        
        [JsonPropertyName("conversion_result")]
        public double ConversionResult { get; set; }
    }
}
