﻿using Exchangerate.Integration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ExchangerateApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ExchangeratesController : ControllerBase
    {
        private readonly IGetExchangerates _exchangerates;
        private readonly IApiKeyEnvirometSettings _apiKeyEnviromentSettings;
        private readonly ILogger<ExchangeratesController> _logger;

        public ExchangeratesController(
            IApiKeyEnvirometSettings apiKeyEnviromentSettings,
            IGetExchangerates exchangerates,
            ILogger<ExchangeratesController> logger)
        {
            _exchangerates = exchangerates;
            _apiKeyEnviromentSettings = apiKeyEnviromentSettings;
            _logger = logger;
        }

        [HttpGet]
        [Route("{currency}")]
        public async Task<IActionResult> GetExchangeratesByCurrency(string currency)
        {
            var apiKey = _apiKeyEnviromentSettings.ApiKey;

            try {
                var result = await _exchangerates.GetExchangeratesByCurrency(apiKey, currency).ConfigureAwait(false);
                return Ok(result);
            } catch (Exception ex) {
                _logger.LogError(ex, $"Failed to get exchange rates for currency '{currency.ToUpper()}'");
                return BadRequest($"Failed to get exchange rates for currency '{currency.ToUpper()}'");
            }
        }

        [HttpGet]
        [Route("exchange")]
        public async Task<IActionResult> GetExchangeResultByCurrenciesAndAmount(string cFrom, string cTo, double amount)
        {
            var apiKey = _apiKeyEnviromentSettings.ApiKey;

            try {
                var result = await _exchangerates.GetExchangeResultByCurrenciesAndAmount(apiKey, cFrom, cTo, amount).ConfigureAwait(false);
                return Ok(result);
            } catch (Exception ex) {
                _logger.LogError(ex, $"Failed to perform currency exchange for '{cFrom.ToUpper()}' to '{cTo.ToUpper()}'");
                return BadRequest($"Failed to perform currency exchange for '{cFrom.ToUpper()}' to '{cTo.ToUpper()}'");
            }
        }
    }
}
